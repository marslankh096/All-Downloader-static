// AppPagerItemCallback.kt
package com.app.alldownloaderstatic

interface AppPagerItemCallback {
    fun onAppPagerItemClick(item: AppMenuItem)
}
