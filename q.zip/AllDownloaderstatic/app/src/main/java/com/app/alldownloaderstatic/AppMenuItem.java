package com.app.alldownloaderstatic;
public class AppMenuItem {
    private int drawable;
    private String name;
    private String defaultUrl;

    public String getDefaultUrl() {
        return defaultUrl;
    }

    public void setDefaultUrl(String defaultUrl) {
        this.defaultUrl = defaultUrl;
    }

    public AppMenuItem(int drawable, String name, String defaultUrl) {
        this.drawable = drawable;
        this.name = name;
        this.defaultUrl = defaultUrl;
    }

    public int getDrawable() {
        return drawable;
    }

    public void setDrawable(int drawable) {
        this.drawable = drawable;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "AppMenuItem{" +
                "drawable=" + drawable +
                ", name='" + name + '\'' +
                ", defaultUrl='" + defaultUrl + '\'' +
                '}';
    }
}
