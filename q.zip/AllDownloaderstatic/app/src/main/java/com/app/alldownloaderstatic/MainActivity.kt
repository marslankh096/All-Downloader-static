package com.app.alldownloaderstatic

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity(), AppPagerItemCallback {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: PagerItemAdapter
    private lateinit var appMenuItems: ArrayList<AppMenuItem>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)

        // Dummy data
        appMenuItems = arrayListOf(
            AppMenuItem(R.drawable.dailymotion, "Facebook", ""),
            AppMenuItem(R.drawable.dailymotion, "Instagram", ""),
            AppMenuItem(R.drawable.dailymotion, "Twitter", ""),
            AppMenuItem(R.drawable.dailymotion, "WhatsApp", "")
        )

        recyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        adapter = PagerItemAdapter(this, this, appMenuItems)
        recyclerView.adapter = adapter
    }

    override fun onAppPagerItemClick(item: AppMenuItem) {
        // Handle click
        // Example:
        when (item.name) {
            "Facebook" -> {
                // do something
            }
            "Instagram" -> {
                // do something
            }
        }
    }
}
