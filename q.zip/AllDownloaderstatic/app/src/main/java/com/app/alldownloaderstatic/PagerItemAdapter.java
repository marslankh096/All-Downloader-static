package com.app.alldownloaderstatic;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
public class PagerItemAdapter extends RecyclerView.Adapter<PagerItemAdapter.GuideHolder> {
    private Context context;
    private AppPagerItemCallback appPagerItemCallback;
    ArrayList<AppMenuItem> appMenuItems;
    public PagerItemAdapter(Context context, AppPagerItemCallback appPagerItemCallback, ArrayList<AppMenuItem> drawablesPage) {
        this.context = context;
        this.appPagerItemCallback = appPagerItemCallback;
        this.appMenuItems = new ArrayList<>(drawablesPage);
    }

    @NonNull
    @Override
    public GuideHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.items_socialbuttons, parent, false);
        return new GuideHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GuideHolder holder, @SuppressLint("RecyclerView") final int position) {
            holder.image.setImageResource(appMenuItems.get(position).getDrawable());
            holder.text_V.setText(appMenuItems.get(position).getName());
            holder.image.setOnClickListener(view -> appPagerItemCallback.onAppPagerItemClick(appMenuItems.get(position)));
    }

    @Override
    public int getItemCount() {
        return appMenuItems.size();
    }

    public static class GuideHolder extends RecyclerView.ViewHolder {

        private ImageView image;
        TextView text_V;

        public GuideHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.imageV);
            text_V = itemView.findViewById(R.id.text_V);
        }
    }

}
