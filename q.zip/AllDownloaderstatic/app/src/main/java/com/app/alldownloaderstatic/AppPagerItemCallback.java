package com.app.alldownloaderstatic;

public interface AppPagerItemCallback {
        void onAppPagerItemClick(AppMenuItem item);
}
