
package com.app.alldownloaderstatic;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PagerAdapter_Icons extends RecyclerView.Adapter<PagerAdapter_Icons.GuideHolder> {

    ArrayList<AppMenuItem> drawablesPage1 = new ArrayList<>();
    ArrayList<AppMenuItem> drawablesPage2 = new ArrayList<>();
    ArrayList<AppMenuItem> drawablesPage3 = new ArrayList<>();
    ArrayList<AppMenuItem> drawablesPage4 = new ArrayList<>();

    private Context context;
    private AppPagerItemCallback appPagerItemCallback;

    public PagerAdapter_Icons(Context context, AppPagerItemCallback appPagerItemCallback) {
        this.context = context;
        this.appPagerItemCallback = appPagerItemCallback;

        //pager 1
        drawablesPage1.add(new AppMenuItem(R.drawable.dailymotion, "Facebook", "https://m.facebook.com/"));
        drawablesPage1.add(new AppMenuItem(R.drawable.dailymotion, "FbWatch", "https://m.facebook.com/watch"));
        drawablesPage1.add(new AppMenuItem(R.drawable.dailymotion, "TikTok", "https://www.tiktok.com/"));
        drawablesPage1.add(new AppMenuItem(R.drawable.dailymotion, "Twitter", "https://twitter.com/watch"));
        drawablesPage1.add(new AppMenuItem(R.drawable.dailymotion, "Insta", "https://www.instagram.com/"));
        drawablesPage1.add(new AppMenuItem(R.drawable.dailymotion, "Dailymotion", "https://www.dailymotion.com/"));
        drawablesPage1.add(new AppMenuItem(R.drawable.dailymotion, "Likee", "https://likee.video/trending?lang=en"));

        //pager 2
        drawablesPage2.add(new AppMenuItem(R.drawable.dailymotion, "Pinrest", "https://www.pinterest.com/search/pins/?rs=typed&q=video"));
        drawablesPage2.add(new AppMenuItem(R.drawable.dailymotion, "Sharechat", "https://sharechat.io/"));
        drawablesPage2.add(new AppMenuItem(R.drawable.dailymotion, "Reddit", "https://www.reddit.com/"));
        drawablesPage2.add(new AppMenuItem(R.drawable.dailymotion, "Imdb", "https://m.imdb.com/trailers/"));
        drawablesPage2.add(new AppMenuItem(R.drawable.dailymotion, "Moj", "https://moj.io/"));
        drawablesPage2.add(new AppMenuItem(R.drawable.dailymotion, "Taktak", "https://taktak.video/live/"));
        drawablesPage2.add(new AppMenuItem(R.drawable.dailymotion, "Chingari", "https://chingari.io/"));

        //pager 3
        drawablesPage3.add(new AppMenuItem(R.drawable.dailymotion, "Roposo", "https://www.roposo.com"));
        drawablesPage3.add(new AppMenuItem(R.drawable.dailymotion, "Vimeo", "https://vimeo.com/watch"));
        drawablesPage3.add(new AppMenuItem(R.drawable.dailymotion, "Snackvideo", "https://www.snackvideo.com"));
        drawablesPage3.add(new AppMenuItem(R.drawable.dailymotion, "Linkdln", "https://www.linkdln.com"));
        drawablesPage3.add(new AppMenuItem(R.drawable.dailymotion, "Ted", "https://www.ted.com"));
        drawablesPage3.add(new AppMenuItem(R.drawable.dailymotion, "Fandom", "https://www.fandom.com"));
        drawablesPage3.add(new AppMenuItem(R.drawable.dailymotion, "Suggestion", "https://www.suggestion.com"));
        drawablesPage3.add(new AppMenuItem(R.drawable.dailymotion, "9gag", "https://9gag.com/search?query=videos"));

       //pager 4
        drawablesPage4.add(new AppMenuItem(R.drawable.dailymotion, "FbStory", "https://www.facebook.com/stories/"));
    }

    @NonNull
    @Override
    public GuideHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.items_socialsites, parent, false);
        return new GuideHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GuideHolder holder, int position) {
        PagerItemAdapter pagerAdapter;
        holder.pagerRv.setVisibility(View.GONE);
        holder.pagerRv.setVisibility(View.VISIBLE);

        if (position == 0) {
            pagerAdapter = new PagerItemAdapter(context, appPagerItemCallback, drawablesPage1);
            holder.pagerRv.setAdapter(pagerAdapter);
        }
        if (position == 1) {
            pagerAdapter = new PagerItemAdapter(context, appPagerItemCallback, drawablesPage2);
            holder.pagerRv.setAdapter(pagerAdapter);
        }
        if (position == 2) {
            pagerAdapter = new PagerItemAdapter(context, appPagerItemCallback, drawablesPage3);
            holder.pagerRv.setAdapter(pagerAdapter);
        }
        if (position == 3) {
            pagerAdapter = new PagerItemAdapter(context, appPagerItemCallback, drawablesPage4);
            holder.pagerRv.setAdapter(pagerAdapter);
        }

    }

    @Override
    public int getItemCount() {
        return 4;
    }

    public static class GuideHolder extends RecyclerView.ViewHolder {

        private RecyclerView pagerRv;

        public GuideHolder(@NonNull View itemView) {
            super(itemView);
            pagerRv = itemView.findViewById(R.id.pagerRv);
        }
    }
}
