// AppMenuItem.kt
package com.app.alldownloaderstatic

data class AppMenuItem(val drawable: Int, val name: String)
